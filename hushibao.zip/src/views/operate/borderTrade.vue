<template>
	<div>
		边贸交易管理
	</div>
</template>