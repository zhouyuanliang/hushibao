<template>
	<div>
		内贸交易管理
	</div>
</template>