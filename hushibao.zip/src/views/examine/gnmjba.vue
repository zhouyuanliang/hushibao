<template>
	<div>
		国内买家
	</div>
</template>