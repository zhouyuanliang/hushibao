<template>
	<div>
		边民备案
	</div>
</template>