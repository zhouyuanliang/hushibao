<template>
	<div>
		首页 - 交易统计分析
	</div>
</template>