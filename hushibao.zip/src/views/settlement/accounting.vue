<template>
	<div>
		会计中心
	</div>
</template>