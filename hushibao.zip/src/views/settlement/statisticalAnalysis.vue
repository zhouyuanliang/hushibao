<template>
	<div>
		统计分析
	</div>
</template>