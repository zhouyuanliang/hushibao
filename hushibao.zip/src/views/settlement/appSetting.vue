<template>
	<div>
		APP管理
	</div>
</template>