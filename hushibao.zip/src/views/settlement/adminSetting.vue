<template>
	<div>
		管理员设置
	</div>
</template>