import Vue from 'vue'

// import Topbar from './topbar/topBar'




const install = (Vue, options) => {
    // 公共组件
    // Vue.component('sy-topbar', Topbar);

};
export default {
    install
}